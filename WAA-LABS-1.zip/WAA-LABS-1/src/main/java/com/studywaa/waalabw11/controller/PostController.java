package com.studywaa.waalabw11.controller;

import com.studywaa.waalabw11.entity.Post;
import com.studywaa.waalabw11.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/posts")

public class PostController {
    private final PostService postService;
   @Autowired
    public PostController(PostService postService) {
        this.postService = postService;
    }
    @ResponseStatus(HttpStatus.OK)
  @GetMapping
    public List<Post> getAll() {
       return postService.findAll();
    }

    @GetMapping("/{id}")
    public Post getPostById(@PathVariable long id){
         return postService.getById(id);
    }
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping
    public void save(@RequestBody  Post p){
       postService.save(p);
    }
    @ResponseStatus(HttpStatus.OK)
    @DeleteMapping("/{id}")
    public void delete(@PathVariable long id){
       postService.delete(id);
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PutMapping("/{id}")
    public void update(@PathVariable("id") long id, @RequestBody Post p){
       postService.update(id,p);
    }

}


