package com.studywaa.waalabw11.dto;

import lombok.Getter;
import lombok.Setter;

public class PostName
{
    @Getter
    @Setter
    private String title;
}


