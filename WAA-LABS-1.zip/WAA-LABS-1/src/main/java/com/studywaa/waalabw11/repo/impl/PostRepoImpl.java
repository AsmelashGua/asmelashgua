package com.studywaa.waalabw11.repo.impl;

import com.studywaa.waalabw11.entity.Post;
import com.studywaa.waalabw11.repo.PostRepo;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PostRepoImpl implements PostRepo {


   private long postId = 10;
   private static List<Post> posts ;
   static {

       posts = new ArrayList<>();
       Post p1 = new Post(1, "Title 1", "contetnt 1", "Author 1");
       Post p2 = new Post(2, "Title 2", "content 2", "Author 2");
       Post p3 = new Post(3, "Title 3", "content 3", "Author 3");
       posts.add(p1);
       posts.add(p2);
       posts.add(p3);
   }


    @Override
    public List<Post> findAll() {
            return posts;
    }

    @Override
    public Post getById(long id) {
        return posts
              .stream()
                .filter(i -> i.getId() == id)
                .findFirst()
               .orElse(null);
    }

    @Override
    public void save(Post p) {
        p.setId(postId); // We are auto generating the id for DEMO purposes, (Normally, do not change your parameters)
          postId++;
          posts.add(p);
    }

    @Override
    public void delete(long id) {
        var post =posts
                .stream()
                .filter(l -> l.getId() == id)
                .findFirst().get();
        posts.remove(post);

    }

    @Override
    public void update(long id, Post p) {
        Post toUpdate = getById(id);
        toUpdate.setAuthor(p.getAuthor());
        toUpdate.setTitle(p.getTitle());
         toUpdate.setContent(p.getContent());


    }
}
