package com.studywaa.waalabw11.entity.dto;

import lombok.Data;

@Data
public class PostDto {
    private long id;
    private String title;
    private String author;
}

//package edu.miu.restful.entity.dto;
//
//        import edu.miu.restful.entity.Review;
//        import lombok.Data;
//
//        import java.util.List;
//
//@Data
//public class ProductDto {
//
//    private int id;
//    private String name;
//    private float price;
//
//}